import zipfile
import os

files_to_zip = ['app', 'Dockerfile', 'requirements.txt', '.dockerignore']
with zipfile.ZipFile('backend-clean.zip', 'w', zipfile.ZIP_DEFLATED) as zipf:
    for item in files_to_zip:
        if os.path.isdir(item):
            for root, dirs, files in os.walk(item):
                dirs[:] = [d for d in dirs if d not in ['venv', '__pycache__']]
                for file in files:
                    filepath = os.path.join(root, file)
                    arcname = os.path.join('backend', filepath)
                    zipf.write(filepath, arcname)
        else:
            zipf.write(item, os.path.join('backend', item))

print('backend-clean.zip creado exitosamente')
size_kb = os.path.getsize('backend-clean.zip') / 1024
print(f'Tamaño: {size_kb:.1f} KB')
