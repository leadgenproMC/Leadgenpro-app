import zipfile
import os

EXCLUDE_DIRS = {'node_modules', '.next', '__pycache__'}
EXCLUDE_FILES = {'.env.local'}

def create_frontend_zip():
    frontend_dir = r'c:\Users\Portatil\Documents\My Web Sites\Leadgenpro\frontend'
    output_zip = os.path.join(frontend_dir, 'frontend-vercel.zip')
    
    with zipfile.ZipFile(output_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(frontend_dir):
            dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
            
            for file in files:
                filepath = os.path.join(root, file)
                arcname = os.path.relpath(filepath, frontend_dir)
                
                if os.path.basename(file) not in EXCLUDE_FILES:
                    zipf.write(filepath, arcname)
    
    size_mb = os.path.getsize(output_zip) / (1024 * 1024)
    print(f'ZIP creado: {output_zip}')
    print(f'Tamaño: {size_mb:.2f} MB')

if __name__ == '__main__':
    create_frontend_zip()
